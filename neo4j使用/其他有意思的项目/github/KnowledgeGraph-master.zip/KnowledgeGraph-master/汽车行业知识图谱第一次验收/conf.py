#coding:utf-8
'''
Created on 2017年12月11日

@author: qiujiahao

@email:997018209@qq.com

'''
#数据路径
DATA_PATH='data/web'

#MYSQL信息
MYSQL_HOST="192.168.1.245"
MYSQL_PORT=3306
MYSQL_USER="knowInfo"
MYSQL_PASSWORD="knowInfo"
MYSQL_db='KnowGrah_car_info'

#web
http_host='0.0.0.0'
http_port=8090
#json_path="/templates/data.json"
json_path="/server/templates/data.json"


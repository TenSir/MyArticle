#coding:utf-8
'''
Created on 2018年1月9日

@author: qiujiahao

@email:997018209@qq.com

'''
from flask import Flask
app = Flask(__name__)
from server.views import *
1.使用介绍:第二讲 知识表示和知识建模 (1).pdf

2.安装程序:Protege-5.0.0-beta-16.zip

3.示例程序:KGexample.owl

4.效果:效果.PNG

5.作用:本体建模